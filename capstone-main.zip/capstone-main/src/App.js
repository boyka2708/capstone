import './App.css';

function App() {
  return (
    <>
      <header></header>
      <nav></nav>
      <main></main>
      <footer></footer>
    </>
  );
}

export default App;
