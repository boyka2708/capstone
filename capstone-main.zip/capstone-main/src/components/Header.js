function Header() {
    return (
    <header>
        <meta name="description" content="your text goes here"/>
        <meta name="og:title" content=""/>
        <meta name="og:description" content=""/>
        <meta name="og:image" content=""/>
    </header>
    )
}

export default Header