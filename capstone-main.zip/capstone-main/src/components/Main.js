function Main() {
    return <main></main>
}

export default Main