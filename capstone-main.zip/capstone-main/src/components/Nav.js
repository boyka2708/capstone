function Nav() {
    return (
        <nav>
            <img src='' alt='Little Lemon Logo' />
            <ul>
                <li></li>
            </ul>
        </nav>
    )
}

export default Nav